const express = require('express')
const { getUpload, showCategoryData} = require('./getUploadedImages.controller')
const router = express.Router()


router.post('/',getUpload)//to get acc to category
router.post('/category',showCategoryData)

module.exports = router